"""
Daily Muse Agent
----------------
Runs once a day on an EventBridge schedule. Each run:
  1. Pulls current weather for a fixed lat/lon from Open-Meteo (no API key needed).
  2. Reads the last few entries from DynamoDB so the agent has a memory of what
     it already wrote (avoids repeating the same phrases/themes, lets style drift).
  3. Calls the Anthropic API to write a short poem themed to the weather + date,
     explicitly instructed to diverge stylistically from recent entries.
  4. Renders a simple generative SVG whose palette/shapes are driven by the
     weather condition and a few numbers from the poem (line lengths, mood score).
  5. Writes the result to DynamoDB (history) and to S3 as latest.json, which the
     static site (site/index.html) polls -- so the "app" is just an S3 static
     website that always shows whatever the agent made most recently.

Environment variables (set in template.yaml):
  ANTHROPIC_API_KEY   - secret, injected via SAM parameter / SSM
  TABLE_NAME          - DynamoDB table name
  BUCKET_NAME         - S3 bucket for the static site + latest.json
  LAT / LON           - location for weather theming (defaults: Coimbatore, India)
"""

import os
import json
import random
import urllib.request
import urllib.error
from datetime import datetime, timezone

import boto3

TABLE_NAME = os.environ.get("TABLE_NAME")
BUCKET_NAME = os.environ.get("BUCKET_NAME")
LAT = os.environ.get("LAT", "11.0168")
LON = os.environ.get("LON", "76.9558")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
MODEL = os.environ.get("MODEL", "claude-sonnet-5")

dynamodb = boto3.resource("dynamodb")
s3 = boto3.client("s3")

# WMO weather codes -> (label, palette, mood)
WEATHER_CODES = {
    0: ("clear sky", ["#fdf6e3", "#f7c948", "#3a86ff"], "bright"),
    1: ("mostly clear", ["#fdf6e3", "#f4a259", "#5b9bd5"], "warm"),
    2: ("partly cloudy", ["#e8ecf1", "#9fb4c7", "#6b7b8c"], "calm"),
    3: ("overcast", ["#d6d9e0", "#a0a4ab", "#5c5f66"], "muted"),
    45: ("fog", ["#e5e5e5", "#c9c9c9", "#8a8a8a"], "hazy"),
    48: ("rime fog", ["#eef2f3", "#cfd8dc", "#90a4ae"], "hazy"),
    51: ("light drizzle", ["#dfeeff", "#8ecae6", "#219ebc"], "soft"),
    61: ("light rain", ["#cfe8ff", "#6fa8dc", "#2b5f8a"], "melancholic"),
    63: ("moderate rain", ["#bcd9f0", "#4a7fb5", "#1f3f5c"], "heavy"),
    65: ("heavy rain", ["#9fc1de", "#345d82", "#12283b"], "stormy"),
    71: ("light snow", ["#ffffff", "#dbe9f4", "#a9c6de"], "quiet"),
    80: ("rain showers", ["#c7e0f4", "#5590c4", "#22456b"], "restless"),
    95: ("thunderstorm", ["#2b2d42", "#8d99ae", "#ef233c"], "electric"),
}


def fetch_weather():
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={LAT}&longitude={LON}&current=temperature_2m,weather_code"
    )
    try:
        with urllib.request.urlopen(url, timeout=6) as resp:
            data = json.loads(resp.read().decode())
        current = data.get("current", {})
        code = int(current.get("weather_code", 3))
        temp = current.get("temperature_2m", 25)
    except (urllib.error.URLError, TimeoutError, KeyError, ValueError):
        code, temp = 3, 25
    label, palette, mood = WEATHER_CODES.get(code, WEATHER_CODES[3])
    return {"code": code, "label": label, "temp": temp, "palette": palette, "mood": mood}


def get_recent_entries(limit=5):
    table = dynamodb.Table(TABLE_NAME)
    resp = table.scan(Limit=50)
    items = sorted(resp.get("Items", []), key=lambda x: x["date"], reverse=True)
    return items[:limit]


def build_prompt(weather, recent):
    today = datetime.now(timezone.utc).strftime("%A, %B %d, %Y")
    recent_snippets = "\n".join(
        f"- ({e.get('date')}) theme: {e.get('theme', 'n/a')}, opening line: {e.get('poem', '').splitlines()[0] if e.get('poem') else ''}"
        for e in recent
    ) or "(no prior entries yet - this is the first one)"

    system = (
        "You are a poet-in-residence for a small generative art project. "
        "You write one short original poem per day (6-12 lines), themed to "
        "today's weather and date. You must never repeat a previous opening "
        "line, central image, or structural gimmick. Over time you should "
        "let your style evolve - try a new form, meter, or voice occasionally "
        "rather than settling into a single recognizable pattern. "
        "Return ONLY strict JSON, no markdown fences, no commentary, matching "
        'this schema: {"title": str, "poem": str, "theme": str, "mood_word": str}. '
        "poem should use \\n for line breaks."
    )
    user = (
        f"Today is {today}. Current weather near the site: {weather['label']}, "
        f"{weather['temp']}°C.\n\n"
        f"Recent entries to deliberately diverge from:\n{recent_snippets}\n\n"
        "Write today's poem now."
    )
    return system, user


def call_anthropic(system, user):
    body = json.dumps(
        {
            "model": MODEL,
            "max_tokens": 600,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
    ).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "Content-Type": "application/json",
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        data = json.loads(resp.read().decode())
    text = "".join(block.get("text", "") for block in data.get("content", []))
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        text = text.split("\n", 1)[1] if "\n" in text else text
    return json.loads(text)


def render_svg(weather, poem_data):
    palette = weather["palette"]
    lines = poem_data["poem"].split("\n")
    random.seed(poem_data.get("title", "") + str(datetime.now().date()))
    shapes = []
    for i, line in enumerate(lines[:10]):
        y = 40 + i * 34
        w = min(560, 40 + len(line) * 6)
        opacity = round(random.uniform(0.15, 0.5), 2)
        color = palette[i % len(palette)]
        shapes.append(
            f'<rect x="20" y="{y}" width="{w}" height="18" rx="9" '
            f'fill="{color}" opacity="{opacity}"/>'
        )
    circles = ""
    for _ in range(6):
        cx = random.randint(30, 580)
        cy = random.randint(30, 420)
        r = random.randint(6, 40)
        c = random.choice(palette)
        circles += f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{c}" opacity="0.18"/>'

    svg = f"""<svg viewBox="0 0 620 460" xmlns="http://www.w3.org/2000/svg">
<rect width="620" height="460" fill="{palette[0]}"/>
{circles}
{''.join(shapes)}
</svg>"""
    return svg


def handler(event, context):
    weather = fetch_weather()
    recent = get_recent_entries()
    system, user = build_prompt(weather, recent)
    poem_data = call_anthropic(system, user)
    svg = render_svg(weather, poem_data)

    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    record = {
        "date": date_str,
        "title": poem_data["title"],
        "poem": poem_data["poem"],
        "theme": poem_data.get("theme", weather["label"]),
        "mood_word": poem_data.get("mood_word", weather["mood"]),
        "weather_label": weather["label"],
        "temp": str(weather["temp"]),
        "svg": svg,
    }

    table = dynamodb.Table(TABLE_NAME)
    table.put_item(Item=record)

    s3.put_object(
        Bucket=BUCKET_NAME,
        Key="latest.json",
        Body=json.dumps(record).encode(),
        ContentType="application/json",
        CacheControl="no-cache",
    )

    return {"statusCode": 200, "body": json.dumps({"date": date_str, "title": record["title"]})}
