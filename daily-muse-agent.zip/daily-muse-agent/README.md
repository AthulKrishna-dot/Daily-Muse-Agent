# Daily Muse Agent

An always-on creative agent, not an app you open. Once a day, on its own:

1. Checks the current weather (Open-Meteo, no key needed).
2. Reads its own last few entries from DynamoDB so it doesn't repeat a
   theme, opening line, or structural gimmick — and is nudged to try new
   forms over time.
3. Asks Claude to write a short poem themed to the day + weather.
4. Renders a generative SVG whose palette and shapes come from the weather
   and the poem's own line lengths.
5. Saves everything to DynamoDB (history) and to `latest.json` in a public
   S3 bucket.

The "app" is a single static `index.html` that polls `latest.json`. There's
nothing to open on a schedule — you just visit the URL and whatever's
freshest is already there.

## Architecture (100% AWS Free Tier at this scale)

| Piece | Service | Free tier fit |
|---|---|---|
| Trigger | EventBridge Scheduler | 1 invocation/day — free |
| Compute | Lambda (Python 3.12) | well under 1M req / 400,000 GB-s monthly free tier |
| Memory | DynamoDB (on-demand) | 25GB storage / 25 WCU-RCU free tier, one row/day |
| Storage + hosting | S3 static website | 5GB storage, 20,000 GET/2,000 PUT free tier |

The only non-AWS cost is the Anthropic API call (one short request per day).

## 1. Deploy to AWS

Requires the [AWS SAM CLI](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html) and AWS credentials configured locally (`aws configure`).

```bash
cd daily-muse-agent
sam build
sam deploy --guided
```

During `--guided` you'll be asked for:
- Stack name: `daily-muse-agent`
- AWS Region: your choice
- `AnthropicApiKey`: your Anthropic API key
- `Latitude` / `Longitude`: defaults to Coimbatore, India — change to your location
- Confirm IAM role creation: yes

After it finishes, upload the static site once:

```bash
aws s3 cp site/index.html s3://<SiteBucket-name-from-outputs>/index.html
```

Grab the public URL from the stack outputs:

```bash
aws cloudformation describe-stacks --stack-name daily-muse-agent \
  --query "Stacks[0].Outputs"
```

To generate an entry immediately instead of waiting for the schedule:

```bash
aws lambda invoke --function-name daily-muse-generate out.json && cat out.json
```

## 2. Push to GitHub

```bash
cd daily-muse-agent
git init
git add .
git commit -m "Daily Muse: always-on daily poem + art agent"
git branch -M main
git remote add origin https://github.com/<your-username>/daily-muse-agent.git
git push -u origin main
```

Then add these repo secrets (Settings → Secrets and variables → Actions) so
`.github/workflows/deploy.yml` can deploy on every push:

- `AWS_ACCESS_KEY_ID`
- `AWS_SECRET_ACCESS_KEY`
- `AWS_REGION`
- `ANTHROPIC_API_KEY`

From then on, `git push` to `main` redeploys the stack and re-syncs the site.

## Changing the schedule / theme logic

- `ScheduleExpression` in `template.yaml` is a standard EventBridge cron —
  default is 07:00 IST daily.
- Weather → palette mapping and the "don't repeat yourself" memory logic
  both live in `lambda/generate.py`, in `WEATHER_CODES` and
  `get_recent_entries` / `build_prompt`.
- To remix community prompts instead of weather: swap `fetch_weather()` for
  a call to wherever prompts are submitted (a DynamoDB table, a form
  backend, a subreddit API, etc.) and feed that into `build_prompt`.

## Why I couldn't run the deploy/push myself

I don't have AWS credentials or a GitHub connection wired into this
environment (no network egress in my sandbox, no connected AWS/GitHub
tools), so I built the full repo and IaC but the two commands above are
yours to run with your own credentials.
